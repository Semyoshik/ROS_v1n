#!/bin/bash

echo "Установка зависимостей..."
sudo apt update
sudo apt install -y ros-noetic-gazebo-ros ros-noetic-gazebo-plugins python3-pip
pip3 install -r requirements.txt

echo "Настройка симулятора..."
source /opt/ros/noetic/setup.bash
catkin_make

echo "Копирование конфигураций..."
cp config/clover.launch ~/catkin_ws/src/clover/clover/launch/
cp config/aruco.launch ~/catkin_ws/src/clover/aruco_pose/launch/

echo "Готово! Запустите симуляцию через Gazebo."
