import rospy
from std_msgs.msg import String

def main():
    rospy.init_node('drone_scanner')
    pub = rospy.Publisher('/buildings', String, queue_size=10)
    
    rospy.loginfo("Начало сканирования...")
    buildings = [
        {"x": 1, "y": 2, "color": "red"},
        {"x": 3, "y": 4, "color": "green"},
    ]
    
    for building in buildings:
        message = f"Building at ({building['x']}, {building['y']}), color: {building['color']}"
        pub.publish(message)
        rospy.loginfo(message)
    
    rospy.loginfo("Сканирование завершено.")
    rospy.spin()

if __name__ == "__main__":
    try:
        main()
    except rospy.ROSInterruptException:
        pass
