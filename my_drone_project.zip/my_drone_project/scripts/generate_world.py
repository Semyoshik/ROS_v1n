import random
import json

BUILDINGS_COUNT = 5
MIN_DISTANCE = 1
AREA_SIZE = (0, 9)
COLORS = ['red', 'green', 'yellow', 'blue']

buildings = []
for _ in range(BUILDINGS_COUNT):
    while True:
        x, y = random.uniform(*AREA_SIZE), random.uniform(*AREA_SIZE)
        if all(((x - b['x'])**2 + (y - b['y'])**2)**0.5 >= MIN_DISTANCE for b in buildings):
            color = random.choice(COLORS)
            buildings.append({'x': x, 'y': y, 'color': color})
            break

with open('world.json', 'w') as f:
    json.dump(buildings, f)
print("Мир успешно сгенерирован!")
