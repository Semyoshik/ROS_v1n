document.addEventListener("DOMContentLoaded", () => {
    console.log("Карта загружена");
});