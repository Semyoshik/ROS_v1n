# Drone Monitoring System

## Установка
1. Клонируйте репозиторий:
   ```bash
   git clone <REPO_URL>
   cd my_drone_project
   ```
2. Установите зависимости:
   ```bash
   bash scripts/setup_simulation.sh
   ```

## Использование
1. Генерация мира:
   ```bash
   python3 scripts/generate_world.py
   ```
2. Запуск симуляции:
   ```bash
   roslaunch clover clover.launch
   ```
3. Запуск ROS-ноды:
   ```bash
   python3 scripts/drone_scan.py
   ```
4. Запуск веб-интерфейса:
   ```bash
   python3 web/app.py
   ```
